export interface SavedPopup {
  id: string;
  name: string;
  date: string;
  time: string;
  attendees: number;
  description: string;
  location: string;
  imageUrl: string;
}
